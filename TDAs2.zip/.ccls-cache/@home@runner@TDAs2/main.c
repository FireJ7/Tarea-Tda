#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>

// Función para limpiar la pantalla
void limpiarPantalla() { system("clear"); }

void presioneTeclaParaContinuar() {
  puts("Presione una tecla para continuar...");
  getchar(); // Consume el '\n' del buffer de entrada
  getchar(); // Espera a que el usuario presione una tecla
}

// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}

void registrar_paciente(List *pacientes) 
{
  printf("Registrar nuevo paciente\n");
  char nombre[50];
  int edad;
  char sintomas[100];

  printf("Ingrese el nombre del paciente: ");
  scanf(" %[^\n]", nombre);
  printf("Ingrese la edad del paciente: ");
  scanf("%d", &edad);
  printf("Ingrese los síntomas del paciente: ");
  scanf(" %[^\n]", sintomas);
  Paciente *nuevoPaciente = (Paciente *)malloc(sizeof(Paciente));
  if (nuevoPaciente == NULL)
  {
    printf("Error al asignar memoria para el paciente.\n");
    free(nuevoPaciente);
    return;
    
  }
  strcpy(nuevoPaciente->nombre, nombre);
  nuevoPaciente->edad = edad;
  strcpy(nuevoPaciente->sintomas, sintomas);
  
  time_t horaActual = time(NULL);
  nuevoPaciente->horaRegistro = horaActual;
  strcpy(nuevoPaciente->prioridad, "Bajo");
  
  list_pushBack(pacientes, nuevoPaciente);
  
}
void mostrar_lista_pacientes(List *pacientes) 
{
  printf("Lista de pacientes:\n");
  int contador = 1;
  void *paciente = list_first(pacientes);
  while (paciente != NULL)
    {
      Paciente *paciente_actual = (Paciente *)paciente;
      printf("%d.\n", contador);
      printf("Nombre: %s\n", paciente_actual->nombre);
      printf("Edad: %d\n", paciente_actual->edad);
      printf("Síntoma: %s\n", paciente_actual->sintomas);
      printf("Hora de registro: %s\n", ctime(&paciente_actual->horaRegistro));
      printf("Prioridad: %s\n", paciente_actual->prioridad);
      paciente = list_next(pacientes);
      contador++;
    }
  
}
int comparar(void *paciente1, void *paciente2)
{
    Paciente *p1 = (Paciente *)paciente1;
    Paciente *p2 = (Paciente *)paciente2;

    char *prioridades[] = {"Alto", "Medio", "Bajo"};
    int prioridad1 = -1, prioridad2 = -1;

    for (int i = 0; i < 3; i++)
    {
        if (strcmp(p1->prioridad, prioridades[i]) == 0)
        {
            prioridad1 = i;
        }
        if (strcmp(p2->prioridad, prioridades[i]) == 0)
        {
            prioridad2 = i;
        }
    }

    if (prioridad1 != prioridad2)
    {
        return prioridad1 - prioridad2;
    }
    else
    {
        
        return difftime(p1->horaRegistro, p2->horaRegistro);
    }
}

void asignar_prioridad(List *pacientes)
{
    printf("Asignar prioridad a paciente\n");
    char nombre[50];
    printf("Ingrese el nombre del paciente: ");
    scanf(" %[^\n]", nombre);

    
    void *paciente = list_first(pacientes);
    while (paciente != NULL)
    {
        Paciente *paciente_actual = (Paciente *)paciente;
        if (strcmp(paciente_actual->nombre, nombre) == 0)
        {
            printf("Seleccione la nueva prioridad para el paciente:\n");
            printf("1. Alto\n");
            printf("2. Medio\n");
            printf("3. Bajo\n");
            int opcion;
            printf("Ingrese su opción: ");
            scanf("%d", &opcion);
            switch (opcion)
            {
            case 1:
                strcpy(paciente_actual->prioridad, "Alto");
                printf("Prioridad asignada al paciente: Alto.\n");
                break;
            case 2:
                strcpy(paciente_actual->prioridad, "Medio");
                printf("Prioridad asignada al paciente: Medio.\n");
                break;
            case 3:
                strcpy(paciente_actual->prioridad, "Bajo");
                printf("Prioridad asignada al paciente: Bajo.\n");
                break;
            default:
                printf("Opción inválida. Intente nuevamente.\n");
                break;
            }
            list_popCurrent(pacientes);
            list_sortedInsert(pacientes, paciente_actual, comparar);
            return;
        }
        paciente = list_next(pacientes);
    }

    printf("Paciente no encontrado.\n");
}

void filtrar_pacientes(List *pacientes, char *prioridad)
{
  if (list_isEmpty(pacientes))
  {
    printf("No hay pacientes en la lista.\n");
    return;
  }
  void *paciente = list_first(pacientes);
  while(paciente != NULL)
    {
      Paciente *paciente_actual = (Paciente *)paciente;
      if (strcmp(paciente_actual->prioridad, prioridad) == 0)
      {
        printf("Nombre: %s\n", paciente_actual->nombre);
        printf("Edad: %d\n", paciente_actual->edad);
        printf("Síntoma: %s\n", paciente_actual->sintomas);
        printf("Hora de registro: %s\n", ctime(&paciente_actual->horaRegistro));
        printf("Prioridad: %s\n", paciente_actual->prioridad);
      }
      paciente = list_next(pacientes);
      
    }
  
}


void mostrar_pacientesPrioridad(List *pacientes)
{
  printf("Pacientes por prioridad:\n");
  char opcion[10];
  
  printf("Ingrese prioridad a buscar");
  scanf("%s", opcion);
  filtrar_pacientes(pacientes, opcion);
}
    
void atender_paciente(List *pacientes)
{
  if (list_isEmpty(pacientes))
  {
    printf("No hay pacientes en la lista.\n");
    return;
  }
  Paciente *paciente_actual = (Paciente *)list_popFront(pacientes);
  printf("Nombre: %s\n", paciente_actual->nombre);
  printf("Edad: %d\n", paciente_actual->edad);
  printf("Síntoma: %s\n", paciente_actual->sintomas);
  printf("Hora de registro: %s\n", ctime(&paciente_actual->horaRegistro));
  printf("Prioridad: %s\n", paciente_actual->prioridad);
  
  free(paciente_actual);
}

int main() {
  char opcion;
  List *pacientes = list_create(); // puedes usar una lista para gestionar los pacientes

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %c", &opcion); // Nota el espacio antes de %c para consumir el
                           // newline anterior

    switch (opcion) {
    case '1':
      registrar_paciente(pacientes);
      break;
    case '2':
      asignar_prioridad(pacientes);
      break;
    case '3':
      mostrar_lista_pacientes(pacientes);
      break;
    case '4':
      atender_paciente(pacientes);
      break;
    case '5':
      mostrar_pacientesPrioridad(pacientes);
      break;
    case '6':
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

  } while (opcion != '6');

  // Liberar recursos, si es necesario
  list_clean(pacientes);

  return 0;
}
